package com.example.proyecto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.proyecto.R
import com.example.proyecto.ui.theme.ProyectoTheme // Cambia esto a tu tema

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFE0F0E0) // Color de fondo verde claro
                ) {
                    ProfileCard()
                }
            }
        }
    }
}

@Composable
fun ProfileCard() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE0F0E0))
            .padding(16.dp)
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Box(
                modifier = Modifier
                    .size(96.dp)
                    .background(Color(0xFF073042)),
                contentAlignment = Alignment.Center
            ) {

                Image(
                    painter = painterResource(id = R.drawable.android_logo),
                    contentDescription = "Android Logo",
                    modifier = Modifier.size(80.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = stringResource(id = R.string.profile_name),
                fontSize = 28.sp,
                color = Color(0xFF073042)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = stringResource(id = R.string.profile_title),
                fontSize = 14.sp,
                color = Color(0xFF2E7D32)
            )
        }


        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ContactInfo(
                icon = Icons.Default.Phone,
                text = stringResource(id = R.string.profile_phone),
                contentDescription = stringResource(id = R.string.desc_phone_icon)
            )

            Spacer(modifier = Modifier.height(16.dp))

            ContactInfo(
                icon = Icons.Default.Share,
                text = stringResource(id = R.string.profile_social),
                contentDescription = stringResource(id = R.string.desc_share_icon)
            )

            Spacer(modifier = Modifier.height(16.dp))

            ContactInfo(
                icon = Icons.Default.Email,
                text = stringResource(id = R.string.profile_email),
                contentDescription = stringResource(id = R.string.desc_email_icon)
            )
        }
    }
}

@Composable
fun ContactInfo(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    contentDescription: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = Color(0xFF2E7D32),
            modifier = Modifier.size(20.dp)
        )

        Spacer(modifier = Modifier.width(16.dp))

        Text(
            text = text,
            fontSize = 14.sp
        )
    }
}
@Preview(showBackground = true)
@Composable
fun ProfileCardPreview() {
    ProyectoTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFFE0F0E0)
        ) {
            ProfileCard()
        }
    }
}